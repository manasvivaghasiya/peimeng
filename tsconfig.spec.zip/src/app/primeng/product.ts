export interface product{
     category:string;
     productName: string;
     description:string;
     price:number;
     clothSize:number;
     inStock:string;
     _id:string;

}